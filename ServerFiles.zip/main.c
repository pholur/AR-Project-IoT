#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <signal.h>
#include <pthread.h>
#include "server.h"

#define PORTNO 5591

double max_delayA = 700000000;
double max_delayB = 700000000;

// Level Manager for Next Gen Program
int levelA = 1; // max levels = 5
int levelB = 1;


int A_hits = 0; // number of A hits < 3
int B_hits = 0; // number of B hits < 3
int health_flag = 0; // -1 for Yoda, +1 for Force
int health_flag_ = 0;
/////////////////////////////////////////////////

int IMU_A_Attach = 0;
char IMU_A_IP[256];

int Music_Driver = 0;
char Music_Driver_IP[256];

int IMU_B_Attach = 0;
char IMU_B_IP[256];

int Vision_A_Attach = 0;
char Vision_A_IP[256];

int Vision_B_Attach = 0;
char Vision_B_IP[256];

int All_Attach = 0;

int HitRangeA = 0;
int HitRangeB = 0;
int HitRange = 0; // please RESET to 0!

int DecideFlag = 0; // this one changes depending on IMU AND Decision
int PlayerA_Mode = 0; // 1 for Attack, -1 for Block
int PlayerB_Mode = 0;
int delay_Between = 0;

static volatile int run_flag = 1;

void do_when_interrupted()
{
    run_flag = 0;
    printf("\nThreads exiting. Please wait for cleanup operations to complete...\n");
}

void* handle_client(void *arg)
{
    CONNECTION *client;
    int n, client_socket_fd;
    char buffer[256], tmp[256];
    FILE *fp;
    
    client = (CONNECTION *)arg;
    
    client_socket_fd = client->sockfd;
    
    memset(buffer, 0, 256);
    sprintf(buffer, "output_file_IP_%s_TIMESTAMP_%u.csv", client->ip_addr_str, (unsigned)time(NULL));
    printf("filename: %s", buffer);
    
    fp = fopen(buffer, "wb");
    
    while (run_flag) {
        // clear the buffer
        memset(buffer, 0, 256);
        
        // read what the client sent to the server and store it in "buffer"
        n = read(client_socket_fd, buffer, 255);
        // an error has occurred
        if (n < 0) {
            server_error("ERROR reading from socket");
            return NULL;
        }
        // no data was sent, assume the connection was terminated
        if (n == 0) {
            printf("%s has terminated the connection.\n", client->ip_addr_str);
            return NULL;
        }
        
        // print the message to console
        if (!All_Attach) {
              printf("%s says: %s\n", client->ip_addr_str, buffer);
              fprintf(fp, "%s\n", buffer);
        }
        
        // Entering the First Pass Data into Global Variables
        //
        //
        //
        //
        if (!All_Attach) {
            if (IMU_A_Attach == 0 && strcmp(buffer,"100")==0) {
                IMU_A_Attach = 1;
                strcpy(IMU_A_IP, client->ip_addr_str);
                continue; //dont want 100 to be the first value of the job
            }
            
            if (IMU_B_Attach == 0 && strcmp(buffer,"101")==0) {
                IMU_B_Attach = 1;
                strcpy(IMU_B_IP, client->ip_addr_str);
                continue;
            }
            
            if (Vision_A_Attach == 0 && strcmp(buffer,"102")==0) {
                Vision_A_Attach = 1;
                strcpy(Vision_A_IP, client->ip_addr_str);
                continue;
            }
            
            if (Vision_B_Attach == 0 && strcmp(buffer,"103")==0) {
                Vision_B_Attach = 1;
                strcpy(Vision_B_IP, client->ip_addr_str);
                continue;
            }
            
        }

        //
        //
        //
        //
        
        
        
        
        // send an acknowledgement back to the client saying that we received the message
        // ACK should be of type requested by client
        memset(tmp, 0, sizeof(tmp));
        //
        //
        if (All_Attach) {
            
            if (strcmp(client->ip_addr_str, IMU_A_IP) == 0) {
                if (strcmp(buffer, "1") == 0 && HitRange) {
                    PlayerA_Mode = 1;
                    Music_Driver = 1;
                }
                else if (strcmp(buffer, "2") == 0 && PlayerB_Mode == 1) {
                    PlayerA_Mode = -1;
                    Music_Driver = 2;
                }
                else if (strcmp(buffer, "3") == 0 && HitRange) {
                    PlayerA_Mode = 2;
                    Music_Driver = 1;
                }
                //You can't block if you are not attacked
            }
            
            else if (strcmp(client->ip_addr_str, IMU_B_IP) == 0) {
                if (strcmp(buffer, "1") == 0 && HitRange) {
                    PlayerB_Mode = 1;
                    Music_Driver = 1;
                }
                else if (strcmp(buffer, "2") == 0 && PlayerA_Mode == 1) {
                    PlayerB_Mode = -1;
                    Music_Driver = 2;
                }
                else if (strcmp(buffer, "3") == 0 && HitRange) {
                    PlayerB_Mode = 2;
                    Music_Driver = 1;
                }
            }
            
            //These following parts are to determine if client is close to neighboring client
            else if (strcmp(client->ip_addr_str, Vision_A_IP) == 0) {
                
                if (strcmp(buffer, "1") == 0) {
                    HitRangeA = 1;
                    HitRange = HitRangeA || HitRangeB;
                    health_flag = 0;
                }
                
                else if (strcmp(buffer, "2") == 0) {
                    HitRangeA = 1;
                    HitRange = HitRangeA || HitRangeB;
                    health_flag = -1;
                }
                
                else if (strcmp(buffer, "3") == 0) {
                    HitRangeA = 1;
                    HitRange = HitRangeA || HitRangeB;
                    health_flag = +1;
                }
                
                else if (strcmp(buffer, "4") == 0) {
                    HitRangeA = 0;
                    HitRange = HitRangeA || HitRangeB;
                    health_flag = 0;
                }

                else if (strcmp(buffer, "5") == 0) {
                    HitRangeA = 0;
                    HitRange = HitRangeA || HitRangeB;
                    health_flag = -1;
                }

                else if (strcmp(buffer, "6") == 0) {
                    HitRangeA = 0;
                    HitRange = HitRangeA || HitRangeB;
                    health_flag = +1;
                }

            }
            
            else if (strcmp(client->ip_addr_str, Vision_B_IP) == 0) {
                // Write Logic Code here using Distance Param, Buffer
                if (strcmp(buffer, "1") == 0) {
                    HitRangeB = 1;
                    HitRange = HitRangeA || HitRangeB;
                    health_flag_ = 0;
                }
                
                else if (strcmp(buffer, "2") == 0) {
                    HitRangeB = 1;
                    HitRange = HitRangeA || HitRangeB;
                    health_flag_ = -1;
                }
                
                else if (strcmp(buffer, "3") == 0) {
                    HitRangeB = 1;
                    HitRange = HitRangeA || HitRangeB;
                    health_flag_ = +1;
                }
                
                else if (strcmp(buffer, "4") == 0) {
                    HitRangeB = 0;
                    HitRange = HitRangeA || HitRangeB;
                    health_flag_ = 0;
                }
                
                else if (strcmp(buffer, "5") == 0) {
                    HitRangeB = 0;
                    HitRange = HitRangeA || HitRangeB;
                    health_flag_ = -1;
                }
                
                else if (strcmp(buffer, "6") == 0) {
                    HitRangeB = 0;
                    HitRange = HitRangeA || HitRangeB;
                    health_flag_ = +1;
                }
                
            }
        }
        

        tmp[0] = '9';
        
        n = write(client_socket_fd, tmp, 2);
        if (n < 0) {
            server_error("ERROR writing to socket");
            return NULL;
        }
    }
    
    fclose(fp);
    close(client_socket_fd);
    return NULL;
}



void* manage_server(void *arg)
{
    CONNECTION *server;
    CONNECTION *client;
    int max_connections;
    int i;
    pthread_t tids[256];
    
    // this is the maximum number of connections that the server will accept before
    // turning down additional incoming clients. The server will continue to process
    // old connections until they are terminated
    max_connections = 10;
    
    // setup the server, second argument is how long to wait before realizing there
    // is no incoming client connection (IE: timeout, unit: SECONDS)
    server = (CONNECTION *) server_init(PORTNO, 10);
    if ((int) server == -1){
        run_flag = 0;
    }
    
    i = -1;
    
    while(i < max_connections && run_flag)
    {
        // wait for a client to connect
        client = (CONNECTION*) server_accept_connection(server->sockfd);
        // no incoming client connection was found
        if ((int) client == -1) {
            printf("Latest child process is waiting for an incoming client connection.\n");
        }
        // an incoming connection was found, service it by spawning a thread to handle the connection
        else {
            i++;
            pthread_create(&tids[i], NULL, handle_client, (void *)client);
        }
    }
    
    if (i >= max_connections) {
        printf("Max number of connections reached. No longer accepting connections. Continuing to service old connections.\n");
    }
    
    // wait for all the child threads to complete before exiting
    for(; i >= 0; i--) {
        pthread_join(tids[i], NULL);
    }
    
    return NULL;
}



void* lol_check(void *arg) {
    while(!All_Attach) {}
    while(All_Attach) {
        if (DecideFlag == 0)
            continue;
        else if (DecideFlag == 1) {
            printf("Jedi has defeated Darth Vader!\n");
            Music_Driver = 3;
            B_hits++;
            
            printf("Hits on A = %d\n", A_hits);
            printf("Hits on B = %d\n", B_hits);
            
            DecideFlag = 0;
        }
        else if (DecideFlag == 2) {
            printf("Darth Vader has defeated Jedi!\n");
            Music_Driver = 3;
            A_hits++;
            
            printf("Hits on A = %d\n", A_hits);
            printf("Hits on B = %d\n", B_hits);
            
            DecideFlag = 0;
        }
        else if (DecideFlag == 4) {
            printf("Jedi has defeated Darth Vader with special stab!\n");
            Music_Driver = 3;
            B_hits = B_hits + 2;
            
            printf("Hits on A = %d\n", A_hits);
            printf("Hits on B = %d\n", B_hits);
            
            DecideFlag = 0;
        }
        else if (DecideFlag == 5) {
            printf("Darth Vader has defeated Jedi with special stab!\n");
            Music_Driver = 3;
            A_hits = A_hits + 2;
            
            printf("Hits on A = %d\n", A_hits);
            printf("Hits on B = %d\n", B_hits);
            
            DecideFlag = 0;
        }
        
        else if (DecideFlag == 3) {
            printf("Duel goes ON!\n");
            
            printf("Hits on A = %d\n", A_hits);
            printf("Hits on B = %d\n", B_hits);
            
            Music_Driver = 3;
            DecideFlag = 0;
        }
    }
    return NULL;
}


void* audio(void *arg) {
    while (!All_Attach){
        system("afplay /Users/pavan/Desktop/IoT_Capstone/MusicStarWars/Non_Connect.wav");
    }
    while (All_Attach) {
        switch (Music_Driver) {
            case 1:
                system("afplay /Users/pavan/Desktop/IoT_Capstone/MusicStarWars/Attack.wav");
                Music_Driver = 0;
                break;
            case 2:
                system("afplay /Users/pavan/Desktop/IoT_Capstone/MusicStarWars/Block.wav");
                Music_Driver = 0;
                break;
            case 3:
                system("afplay /Users/pavan/Desktop/IoT_Capstone/MusicStarWars/WinDuel.wav");
                Music_Driver = 0;
                break;
            case 4:
                system("afplay /Users/pavan/Desktop/IoT_Capstone/MusicStarWars/LevelUP_Yoda.wav");
                Music_Driver = 0;
                break;
            case 5:
                system("afplay /Users/pavan/Desktop/IoT_Capstone/MusicStarWars/LevelUP_Vader.wav");
                Music_Driver = 0;
                break;
        }
    }
    return NULL;
}





void* dev_manager(void *arg) {
    while(!All_Attach) {}
    while(All_Attach) {
        
        if (levelA > 5) {
            printf("YOU BEAT THE EMPIRE YOUNG PADAWAN!!!\n");
            exit(0);
        }
        
        else if (levelB > 5) {
            printf("The Dark Side Wins!! The FORCE is DOOMED\n");
            exit(0);
        }
        
        else if (A_hits > 3) {
            levelB = levelB + 1;
            max_delayB = max_delayB - 100000000;
            Music_Driver = 5;
            printf("Try Harder, the Dark Side is taking the Upper Hand. VADER LEVELLED UP\n");
            A_hits = 0;
            B_hits = 0;
        }
        
        else if (B_hits > 3) {
            levelA = levelA + 1;
            max_delayA = max_delayA - 100000000;
            printf("The Green Squad is on the Right Path to winning. SQUAD LEVELLED UP\n");
            Music_Driver = 4;
            A_hits = 0;
            B_hits = 0;
        }
        
        if (health_flag != 0) {
            if (health_flag == +1) {
                A_hits = 0;
            }
            else if (health_flag == -1) {
                if (A_hits > 0) {
                    A_hits --;
                }
            }
            printf("Hits on A = %d\n", A_hits);
            health_flag = 0;
        }
        
        if (health_flag_ != 0) {
            if (health_flag_ == +1) {
                B_hits = 0;
            }
            else if (health_flag_ == -1) {
                if (B_hits > 0) B_hits --;
            }
            health_flag_ = 0;
            printf("Hits on B = %d\n", B_hits);
        }

    }
    return NULL;
}


void* yoda(void *arg)
{
    // Initializing All Devices
    while(!All_Attach) {
        if (IMU_A_Attach && IMU_B_Attach && Vision_A_Attach && Vision_B_Attach)
            All_Attach = 1;
    }
    
    // All Devices Attached Now
    // Enter CODE to Decide State of Game
    // RICKY PLEASE REVIEW THE STUFF BELOW
    
    while (run_flag && All_Attach) {
        if (PlayerA_Mode == PlayerB_Mode && PlayerB_Mode != 0) {
            // Attack Cannot Block Attack AND Block Doesnt Affect Block
            PlayerA_Mode = 0;
            PlayerB_Mode = 0;
            continue;
        }
        if ((PlayerA_Mode == 1 && PlayerB_Mode == -1) || (PlayerA_Mode == -1 && PlayerB_Mode == 1) || (PlayerA_Mode == 2 && PlayerB_Mode == -1) || (PlayerA_Mode == -1 && PlayerB_Mode == 2)) {
            // Rarely in case of race condition or trap, if block and attack are static
            PlayerA_Mode = 0;
            PlayerB_Mode = 0;
            // Output Display of Drawn DUEL
            DecideFlag = 0;
            continue;
        }
        
        if (PlayerA_Mode == 1 || PlayerA_Mode == 2) {
            while (delay_Between < max_delayB) {
                if (PlayerB_Mode == -1) {
                    PlayerA_Mode = 0;
                    PlayerB_Mode = 0;
                    // DRAW Output -- OUTPUT
                    DecideFlag = 3;
                    break;
                }
                else {
                    delay_Between = delay_Between + 1;
                }
            }
            delay_Between = 0;
            
            // PLAYER A WINS -- OUTPUT
            if (DecideFlag == 0) {
                if (PlayerA_Mode == 1)
                    DecideFlag = 1;
                if (PlayerA_Mode == 2)
                    DecideFlag = 4;
            }
            
            PlayerA_Mode = 0;
            PlayerB_Mode = 0;
            
            continue;
        }
        
        
        else if (PlayerB_Mode == 1 || PlayerB_Mode == 2) { // changed
            // 5000 IS ARBITRARY! PLEASE CHANGE
            while (delay_Between < max_delayA) {
                if (PlayerA_Mode == -1) {
                    PlayerA_Mode = 0;
                    PlayerB_Mode = 0;
                    // DRAW Output -- OUTPUT
                    DecideFlag = 3;
                    break;
                }
                else
                    delay_Between = delay_Between + 1;
            }
            delay_Between = 0;

            // PLAYER B WINS -- OUTPUT
            if (DecideFlag == 0) {
                if (PlayerB_Mode == 1)
                    DecideFlag = 2;
                if (PlayerB_Mode == 2)
                    DecideFlag = 5;
            }
            PlayerA_Mode = 0;
            PlayerB_Mode = 0;
            continue;
        }
    }
    return NULL;
}



int main(int argc, char **argv)
{
    pthread_t manage_server_tid, yoda_tid, lol_check_tid, dev_manager_tid, audio_tid;
    int rc;
    
    signal(SIGINT, do_when_interrupted);
    
    rc = pthread_create(&manage_server_tid, NULL, manage_server, NULL);
    if (rc != 0) {
        fprintf(stderr, "Failed to create manage_server thread. Exiting program.\n");
        exit(0);
    }
    
    rc = pthread_create(&yoda_tid, NULL, yoda, NULL);
    if (rc != 0) {
        fprintf(stderr, "Failed to create yoda thread. Exiting program.\n");
        exit(0);
    }
    
    rc = pthread_create(&lol_check_tid, NULL, lol_check, NULL);
    if (rc != 0) {
        fprintf(stderr, "Failed to create lolcheck thread. Exiting program.\n");
        exit(0);
    }
    
    rc = pthread_create(&dev_manager_tid, NULL, dev_manager, NULL);
    if (rc != 0) {
        fprintf(stderr, "Failed to create dev thread. Exiting program.\n");
        exit(0);
    }
    
    rc = pthread_create(&audio_tid, NULL, audio, NULL);
    if (rc != 0) {
        fprintf(stderr, "Failed to create audio thread. Exiting program.\n");
        exit(0);
    }

    pthread_join(manage_server_tid, NULL);
    printf("\n...cleanup operations complete. Exiting main.\n");
    return 0;
}
