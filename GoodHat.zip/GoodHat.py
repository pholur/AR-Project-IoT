import subprocess
import shlex
import sys
import socket
import cv2
import numpy as np
import os.path
import math
import threading
import thread

TCP_IP = '131.179.37.201' #hard coded please change everytime
TCP_PORT = 5591
BUFFER_SIZE = 100
MESSAGES = "0"
MESSAGEV = "0"

lock = threading.Lock()
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((TCP_IP, TCP_PORT))
Mess = "102"
s.send(Mess)

def Sound():
    global MESSAGES
    command = r"pocketsphinx_continuous -inmic yes -logfn nul -hmm /usr/local/share/pocketsphinx/model/en-us/en-us -kws /home/root/MySphinxFolder1/pocketsphinx/model/en-us/keyphrase.list -dict /home/root/MySphinxFolder1/pocketsphinx/model/en-us/keyphrase.dic"
    process = subprocess.Popen(shlex.split(command), stdout=subprocess.PIPE)
    
    while True:
        output = process.stdout.readline().decode()
        if output == '' and process.poll() is not None:
            break
        if "YODA" in output:
            MESSAGES = "3"
        elif "FORCE" in output:
            MESSAGES = "2"

def Visual():
    global MESSAGEV
    DISTANCE_THRESHOLD = 1

    TIME_DELAY = 100
    FRAME_RATE = 10

    LOWER_BLUE  = np.array([100, 150, 150])
    UPPER_BLUE  = np.array([130, 255, 255])
    LOWER_RED_L = np.array([0,   150, 130])
    UPPER_RED_L = np.array([30,  255, 255])
    LOWER_RED_H = np.array([160, 150, 130])
    UPPER_RED_H = np.array([180, 255, 255])

    COLOR_BLUR_RADIUS = 15
    GRAY_BLUR_RADIUS = 11
    MASK_BLUR_RADIUS = COLOR_BLUR_RADIUS
    
    COLOR_THRESHOLD = 150
    GRAY_THRESHOLD = 220
    MASK_THRESHOLD = COLOR_THRESHOLD
    
    DILATE_KERNEL_SIZE = 41
    DILATE_ITERATIONS = 2

    def capture(video=1, time_delay=TIME_DELAY, color='RED'):
        global MESSAGEV
        cap = cv2.VideoCapture(-1)
        if not cap.isOpened():
            cap.open()

        dilate_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (DILATE_KERNEL_SIZE, DILATE_KERNEL_SIZE))

        while(1):
            ret, frame = cap.read()
            color_mask = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
            gray_mask = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            
            if color == 'BLUE':
                color_mask = cv2.inRange(color_mask, LOWER_BLUE, UPPER_BLUE)
            elif color == 'RED':
                color_mask = cv2.bitwise_or(cv2.inRange(color_mask, LOWER_RED_L, UPPER_RED_L), cv2.inRange(color_mask, LOWER_RED_H, UPPER_RED_H))

            color_mask = cv2.GaussianBlur(color_mask, (COLOR_BLUR_RADIUS, COLOR_BLUR_RADIUS), 0)
            contours = cv2.findContours(color_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[-2]
            cv2.drawContours(color_mask, contours, -1, 255, -1)
            _, color_mask = cv2.threshold(color_mask, COLOR_THRESHOLD, 255, cv2.THRESH_BINARY)
            
            gray_mask = cv2.GaussianBlur(gray_mask, (GRAY_BLUR_RADIUS, GRAY_BLUR_RADIUS), 0)
            _, gray_mask = cv2.threshold(gray_mask, GRAY_THRESHOLD, 255, cv2.THRESH_BINARY)
            gray_mask = cv2.dilate(gray_mask, dilate_kernel, iterations=DILATE_ITERATIONS)
            
            mask = cv2.bitwise_and(color_mask, gray_mask)
            mask = cv2.GaussianBlur(mask, (MASK_BLUR_RADIUS, MASK_BLUR_RADIUS), 0)
            _, mask = cv2.threshold(mask, MASK_THRESHOLD, 255, cv2.THRESH_BINARY)
            contours = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[-2]

            max_radius = -1
            if contours is not None and len(contours) > 0:
                contour_pts = np.asarray(np.concatenate(contours), dtype='int32')
                c, r = cv2.minEnclosingCircle(contour_pts)
                max_radius = int(r)
                max_center = tuple([int(i) for i in c])

            distance = diameter_to_distance(2*max_radius)
            range_str = ''
            if distance < 0:
                range_str = 'Unknown'
                range_flag = 0
                MESSAGEV = "0"
            elif distance <= DISTANCE_THRESHOLD:
                range_str = 'Within Hit Range'
                range_flag = 1
                MESSAGEV = "1"
            else:
                range_str = 'Out of Hit Range'
                range_flag = 0
                MESSAGEV = "0"

            k = cv2.waitKey(video*time_delay) & 0xFF


    def diameter_to_distance(diam, mode='power'):
        if diam < 0:
            return -1
        elif mode == 'power':
            return 382.8802898*math.pow(diam, -1.06554138)

    capture(video=1)
    

def changeDetect():
    
    global MESSAGES
    global MESSAGEV
    
    mess_new = "0"
    mess = "0"
    
    while True:
        if (MESSAGES == "2" and MESSAGEV == "0"):
            mess_new = "6"
        elif (MESSAGES == "2" and MESSAGEV == "1"):
            mess_new = "3"
        elif (MESSAGES == "3" and MESSAGEV == "0"):
            mess_new = "5"
        elif (MESSAGES == "3" and MESSAGEV == "1"):
            mess_new = "2"
        elif (MESSAGES == "0" and MESSAGEV == "0"):
            mess_new = "4"
        elif (MESSAGES == "0" and MESSAGEV == "1"):
            mess_new = "1"

        if (mess != mess_new):
            mess = mess_new
            s.send(mess)
            MESSAGES = "0"

soundThread = threading.Thread(target=Sound)
visualThread = threading.Thread(target=Visual)
detectThread = threading.Thread(target=changeDetect)

soundThread.start()
visualThread.start()
detectThread.start()

soundThread.join()
visualThread.join()
detectThread.join()






