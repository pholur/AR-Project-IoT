#include <stdio.h>
#include <mraa/i2c.h>
#include "LSM9DS0.h"
#include <math.h>
#include "client.h"
#include <signal.h>
#include <mraa.h>
#include <sys/time.h>

float calculate_magnitude(data_t data)
{
	return sqrt(data.x*data.x+data.y*data.y+data.z*data.z);
}

int main(int argc, char * argv[]) {
	mraa_i2c_context accel, gyro;
	float a_res, g_res, m_res;
	accel_scale_t a_scale;
	gyro_scale_t g_scale;
    char buffer[256];//
    int n;//
    int client_socket_fd = client_init(argc, argv, 20);//
    int wait = 0;
    
	data_t ad, gd;
	data_t Go;

	a_scale = A_SCALE_16G;
	g_scale = G_SCALE_245DPS;

	accel = accel_init();
	set_accel_ODR(accel, A_ODR_100);
	set_accel_scale(accel, a_scale);
	a_res = calc_accel_res(a_scale);

	gyro = gyro_init();
	set_gyro_ODR(gyro, G_ODR_190_BW_70);
	set_gyro_scale(gyro, g_scale);
	g_res = calc_gyro_res(g_scale);

	Go = calc_gyro_offset(gyro, g_res);

	int flag = 0;
	int flag1 = 0;
	strcpy(buffer, "101"); //ID for IMU
    n = output(client_socket_fd, buffer);
    memset(buffer, 0, 256);
    
	while(1) {
		ad = read_accel(accel, a_res);
		gd = read_gyro(gyro, g_res);;

		gd.x = gd.x - Go.x;
		gd.y = gd.y - Go.y;
		gd.z = gd.z - Go.z;
		//printf("%9.1f",ad.x); printf("\t");
		//printf("%9.1f",ad.y); printf("\t");
		//printf("%9.1f",ad.z); printf("\t");
		//printf("%9.1f",gd.x); printf("\t");
		//printf("%9.1f",gd.y); printf("\t");
		//printf("%9.1f",gd.z); printf("\t");

		//Enter Decision Tree
		if ((abs(gd.y)*abs(gd.y)) + (abs(gd.z)*abs(gd.z))>60000){
			flag1 = 2;
		}
        else if(abs(gd.x)>210 && abs(ad.x) > 1.7)
        {
            flag1 = 3;
        }
		else if (ad.x > 1.7){
			flag1 = 1;
		}
        	else
            		flag1 = 0;

		if (flag1 != 0 && wait == 0)
       		{
           		if (flag1 == 2)
                    buffer[0] = '2';
                else if (flag1 == 1)
                    buffer[0] = '1';
                else if (flag1 == 3)
                    buffer[0] = '3';
                n = output(client_socket_fd, buffer);
                memset(buffer, 0, 256);
                n = receive(client_socket_fd, buffer);
                flag = flag1;
                wait = wait + 1;
	    		printf("%d\n",flag);
        	}
        	else if (flag != 0 && wait != 0)
        	{
            		wait = wait + 1;
        	}
        	if (flag != 0 && wait > 150)
        	{
            		wait = 0;
            		flag = 0;
            		buffer[0] = '0';
            		n = output(client_socket_fd, buffer);
        	}
        	memset(buffer, 0, 256);
            	//n = receive(client_socket_fd, buffer);
		//memset(buffer, 0, 256);

		//printf("%d\n",flag);
		//printf("%d\n",flag1);
		//printf("%9.3f",calculate_magnitude(md)); printf("\t\n");
	}

	return 0;
}
