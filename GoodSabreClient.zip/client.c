#include <stdio.h>
#include "client.h"

int client_error(const char *msg) //call when client has error, display input const string "xxx"
{
    perror(msg);
    return -1;
}

int client_init(int argc, char *argv[], int timeout_seconds) //return -1 when something is wrong
{
    int client_socket_fd, portno;
    struct sockaddr_in serv_addr;
    struct hostent *server;
    struct timeval timeout;
    
    // Read command line arguments, need to get the host IP address and port
    if (argc < 3) {
        fprintf(stderr,"usage %s hostname port\n", argv[0]);
        return -1;
    }
    
    // Convert the arguments to the appropriate data types
    portno = atoi(argv[2]);
    
    // setup the socket
    client_socket_fd = socket(AF_INET, SOCK_STREAM, 0);
    // check if the socket was created successfully. If it wasnt, display an error and exit
    if(client_socket_fd < 0) {
        return client_error("ERROR opening socket");
    }
    
    // setup the timeout for the socket
    timeout.tv_sec = timeout_seconds;
    timeout.tv_usec = 0;
    if (setsockopt(client_socket_fd, SOL_SOCKET, SO_RCVTIMEO, (char*)&timeout, sizeof(timeout)) < 0) {
        return client_error("ERROR failed to set receive timeout");
    }
    
    // check if the IP entered by the user is valid
    server = gethostbyname(argv[1]);
    if (server == NULL) {
        fprintf(stderr,"ERROR, no such host\n");
        return -1;
    }
    
    // clear our the serv_addr buffer
    memset((char *) &serv_addr, 0, sizeof(serv_addr));
    // set up the socket
    serv_addr.sin_family = AF_INET;
    memcpy((char *)&serv_addr.sin_addr.s_addr, (char *)server->h_addr, server->h_length);
    serv_addr.sin_port = htons(portno);
    
    // try to connect to the server
    if (connect(client_socket_fd,(struct sockaddr *) &serv_addr,sizeof(serv_addr)) < 0){
        return client_error("ERROR connecting");
    }
    
    return client_socket_fd;
}

int output(int client_socket_fd, char * buffer) //the int returned by client_init; data transmitting; return 1 when success
{
    size_t buffer_size = strlen(buffer);
    // send user input to the server
    int n = write(client_socket_fd,buffer,buffer_size);
    
    // n contains how many bytes were received by the server
    // if n is less than 0, then there was an error
    if (n < 0) {
        return client_error("ERROR writing to socket");
    }
    return 1;
}

int receive(int client_socket_fd, char * buffer)
{
    int n = read(client_socket_fd, buffer, 255);
    if (n < 0) {
        return client_error("ERROR reading from socket");
    }
    printf("Message Received:%s\n",buffer);
    return 1;
}

