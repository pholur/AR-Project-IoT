#ifndef client_h
#define client_h
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

int client_error(const char *msg); //call when client has error, display input const string "xxx"
int client_init(int argc, char *argv[], int timeout_seconds); //return -1 when something is wrong
int output(int client_socket_fd, char * buffer); //the int returned by client_init; data transmitting; return 1 when success
int receive(int client_socket_fd, char * buffer); //the int returned by client_init; data receiving; return 1 when success
#endif /* server_h */
